import React from 'react';
import { useParams } from 'react-router-dom'; 
import EditorBlock from '../../components/EditorBlock'; 
import { grammarData } from '../../data/grammarData'; 

export default function GrammarDetail() {
  const { id } = useParams(); 
  
  // 주소창 번호에 맞는 데이터 찾기
  const currentData = grammarData.find(item => item.id === Number(id));

  if (!currentData) {
    return <h1 style={{ color: 'white', padding: '40px' }}>데이터를 찾을 수 없습니다!</h1>;
  }

  return (
    <div style={{ padding: '40px', backgroundColor: '#121212', minHeight: '100vh', color: '#fff', fontFamily: 'sans-serif' }}>
      
      {/* 🌟 [영역 1] 찬영님의 오리지널 기획: 공통 설명과 단축키 */}
      <div style={{ marginBottom: '40px' }}>
        <h1 style={{ fontSize: '32px', color: '#569cd6', marginBottom: '15px' }}>
          {currentData.id}. {currentData.title}
        </h1>
        
        <div style={{ backgroundColor: '#2d2d2d', padding: '20px', borderRadius: '8px', borderLeft: '4px solid #4ec9b0' }}>
          <p style={{ margin: '0 0 10px 0', fontSize: '18px' }}>
            <strong style={{ color: '#dcdcaa' }}>⌨️ 단축키: </strong> 
            {/* 단축키를 진짜 키보드 버튼처럼 예쁘게 꾸밉니다 */}
            <kbd style={{ backgroundColor: '#1e1e1e', padding: '4px 8px', borderRadius: '4px', border: '1px solid #555' }}>
              {currentData.shortcut}
            </kbd>
          </p>
          <p style={{ margin: 0, fontSize: '16px', lineHeight: '1.6', color: '#d4d4d4' }}>
            {currentData.description}
          </p>
        </div>
      </div>
      
      {/* 🌟 [영역 2] 새로운 기획: uiType에 맞춰 튀어나오는 마네킹(체험형 에디터) */}
      <div>
        <h3 style={{ color: '#888', marginBottom: '15px' }}>🖥️ 실제 에디터 화면 (클릭해 보세요!)</h3>
        
        {/* 만약 이 문법이 에디터 마네킹을 쓰는 녀석이라면? EditorBlock을 그려라! */}
        {currentData.uiType === 'editor' && (
          <EditorBlock data={currentData.content} />
        )}
      </div>
      
    </div>
  );
}