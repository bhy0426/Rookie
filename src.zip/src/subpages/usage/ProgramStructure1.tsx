import React from 'react';
import { Link } from 'react-router-dom';
import { programStructureData } from '../../data/programStructureData';

const ProgramStructure1: React.FC = () => {
  // 장부에서 1번 데이터 찾아오기
  const data = programStructureData.find(item => item.id === 1);

  if (!data) return <div>데이터를 불러올 수 없습니다.</div>;

  return (
    <div style={{ padding: '20px', maxWidth: '700px', margin: '0 auto' }}>
      <h2>🛠️ {data.title}</h2>
      <hr />
      <p style={{ fontSize: '16px', lineHeight: '1.7', color: '#333' }}>{data.content}</p>
      
      <div style={{ background: '#f1f5f9', padding: '15px', borderRadius: '6px', margin: '20px 0', fontStyle: 'italic' }}>
        {data.feature}
      </div>

      <Link to="/usage" style={{ color: '#4f46e5' }}>이전 페이지로 가기</Link>
    </div>
  );
};

export default ProgramStructure1;