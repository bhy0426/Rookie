import { useState } from 'react'; // 👈 React라는 단어를 빼서 잔소리 해결!

interface EditorData {
  name: string;
  public: { name: string; value: string }[];
  protected: { name: string; value: string }[];
  private: { name: string; value: string }[];
}

// 👈 export default 가 제대로 붙어있어야 첫 번째 에러가 사라집니다!
export default function EditorBlock({ data }: { data: EditorData }) {
  const [activeTab, setActiveTab] = useState<'public' | 'protected' | 'private'>('public');

  const currentList = data[activeTab];

  return (
    <div style={{ backgroundColor: '#1e1e1e', color: '#d4d4d4', padding: '20px', borderRadius: '10px', maxWidth: '600px', fontFamily: 'monospace' }}>
      
      <h2 style={{ borderBottom: '1px solid #444', paddingBottom: '10px', color: '#569cd6', marginTop: 0 }}>
        📦 {data.name} 객체
      </h2>
      
      <div style={{ display: 'flex', marginTop: '20px' }}>
        <div style={{ width: '100px', borderRight: '1px solid #444', display: 'flex', flexDirection: 'column', gap: '5px', paddingRight: '10px' }}>
          <button onClick={() => setActiveTab('public')} style={{ backgroundColor: activeTab === 'public' ? '#007acc' : 'transparent', color: activeTab === 'public' ? 'white' : '#888', border: 'none', padding: '10px', cursor: 'pointer', textAlign: 'left', borderRadius: '5px' }}>공용</button>
          <button onClick={() => setActiveTab('protected')} style={{ backgroundColor: activeTab === 'protected' ? '#007acc' : 'transparent', color: activeTab === 'protected' ? 'white' : '#888', border: 'none', padding: '10px', cursor: 'pointer', textAlign: 'left', borderRadius: '5px' }}>보호</button>
          <button onClick={() => setActiveTab('private')} style={{ backgroundColor: activeTab === 'private' ? '#007acc' : 'transparent', color: activeTab === 'private' ? 'white' : '#888', border: 'none', padding: '10px', cursor: 'pointer', textAlign: 'left', borderRadius: '5px' }}>전용</button>
        </div>

        <div style={{ flex: 1, paddingLeft: '20px' }}>
          {currentList.length === 0 ? (
            <div style={{ color: '#888', fontStyle: 'italic' }}>내용이 없습니다.</div>
          ) : (
            currentList.map((item, index) => (
              <div key={index} style={{ marginBottom: '12px', fontSize: '16px', display: 'flex', alignItems: 'center' }}>
                <span style={{ color: item.name.includes('()') ? '#dcdcaa' : '#9cdcfe' }}>{item.name}</span>
                {item.value && <span style={{ color: '#d4d4d4', margin: '0 8px' }}> : </span>}
                {item.value && <span style={{ color: '#4ec9b0' }}>{item.value}</span>}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}