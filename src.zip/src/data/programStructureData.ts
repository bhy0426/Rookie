export interface StructureItem {
  id: number;
  title: string;
  content: string;
  feature: string;
}

export const programStructureData: StructureItem[] = [
  {
    id: 1,
    title: "비주얼 프로그래밍 에디터 인터페이스",
    content: "순서도를 조작하는 메인 에디터 화면입니다. 마우스 조작을 위한 UI도 완비되어 있지만 키보드 입력이나 단축키를 사용해서 구문을 생성할 수 있습니다.",
    feature: "주요 특징: 키보드 포커스 이동 기능 및 단축키 바인딩 기본 탑재"
  },
  {
    id: 2,
    title: "키보드 중심 단축키 시스템",
    content: "예약어 대신 단축키를 사용하기 때문에 구문을 만들기 위해 언어 변환 키를 누를 필요 없이 여러 언어로 프로그래밍 할 수 있습니다.",
    feature: "주요 특징: 다국어 코딩 환경 완벽 지원"
  },
  {
    id: 3,
    title: "실시간 컴파일 피드백 엔진",
    content: "텍스트는 아무 글자나 막 칠 수 있지만 숨 언어는 유효하지 않는 입력을 무시하기 때문입니다. 컴파일 오류가 발생하면 작성 즉시 표시가 되기 때문에 바로 수정할 수 있습니다.",
    feature: "주요 특징: 즉각적인 구문 유효성 검증 알고리즘"
  }
];