// 🌟 찬영님의 기획(공통 정보) + 새로운 기획(비주얼 UI)이 합쳐진 인터페이스
export interface GrammarItem {
  id: number;
  title: string;
  shortcut: string;
  description: string;
  uiType: "editor" | "flowchart" | "list"; // 어떤 마네킹을 쓸지 결정
  content: any; // 마네킹 전용 데이터
}

// 🌟 실제 데이터 (일단 테스트용으로 5번과 21번만 넣어둡니다)
export const grammarData: GrammarItem[] = [
  {
    id: 5,
    title: "객체 화면",
    shortcut: "Enter 또는 ;",
    description: "객체 내부에 진입하여 변수와 함수를 관리합니다. 공용, 보호, 전용 탭으로 접근 영역을 설정할 수 있습니다.",
    uiType: "editor", // 에디터 마네킹 사용
    content: {
      name: "플레이어",
      public: [
        { name: "x", value: "4바이트실수" }, 
        { name: "y", value: "4바이트실수" }
      ],
      protected: [
        { name: "생성자()", value: "" },
        { name: "소멸자()", value: "" }
      ],
      private: [
        { name: "그리기()", value: "" }
      ]
    }
  },
  {
    id: 21,
    title: "접근문",
    shortcut: "Alt + Y",
    description: "보호나 전용 영역의 구성변수에 외부에서 접근할 수 있도록 허용하는 구문입니다.",
    uiType: "editor", // 얘도 에디터 마네킹 사용
    content: {
      name: "몬스터",
      public: [],
      protected: [
        { name: "체력", value: "4바이트정수" },
        { name: "공격력", value: "4바이트정수" }
      ],
      private: []
    }
  }
];